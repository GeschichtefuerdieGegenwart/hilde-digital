# Lizenz für Texte und Daten

Konzept, Leitsätze, Kriterien und Texte von Kidu: Mario Walter, 2026.

## Was unter CC BY-NC-SA 4.0 steht

Die Texte der Seiten in `src/`, die Daten in `assets/daten/` (Taxonomien, Kriterien,
Aufträge, Prüflisten, Beispielbeschreibungen), die Dokumentation in `docs/`
sowie `PRODUCT.md` und `DESIGN.md` stehen unter der Lizenz
**Creative Commons Namensnennung – Nicht kommerziell – Weitergabe unter gleichen
Bedingungen 4.0 International (CC BY-NC-SA 4.0)**:
https://creativecommons.org/licenses/by-nc-sa/4.0/deed.de

Das heißt kurz:

- Du darfst das Material teilen und bearbeiten, zum Beispiel für deine Schule oder eine Fortbildung.
- Du nennst dabei den Urheber: »Kidu, Mario Walter, CC BY-NC-SA 4.0«.
- Du nutzt es nicht kommerziell.
- Was du daraus machst, gibst du unter derselben Lizenz weiter.

Maßgeblich ist der Lizenztext von Creative Commons.

## Was nicht unter dieser Lizenz steht

- **Bilder:** Die Bildschirmfotos in `assets/bilder/` und `assets/galerie/` – alle Rechte vorbehalten. Ihre Herkunft steht in `docs/galerie-quellen.md`.
- **Schriften:** `assets/fonts/` – SIL Open Font License, siehe die OFL-Dateien dort.
- **Programmcode:** MIT-Lizenz, siehe `LICENSE`.
- **Der Name** »Kidu« und künftige Namen des Moduls sind von keiner dieser Lizenzen erfasst.
- **Verlinkte Lernanwendungen** liegen in anderen Repositories und haben dort eigene Bedingungen.
- **Skills in `werkzeugkiste/kidu/`:** Die Lizenz je Skill steht in `werkzeugkiste/kidu/LIZENZ.md`. Drei Skills stehen dort, wie schon ihre Aufträge auf der Website, unter CC BY-SA 4.0, weil sie auf einer Vorlage unter dieser Lizenz beruhen.

## Kommerzielle Nutzung

Für eine Nutzung über diese Lizenz hinaus, etwa in kostenpflichtigen Angeboten,
ist eine eigene Vereinbarung mit dem Urheber nötig.
